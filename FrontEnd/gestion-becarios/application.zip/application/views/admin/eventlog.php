<?php
defined('BASEPATH') OR exit('');
?>

<div class="row">
    <div class="col-sm-12">
        <div class="well">
            Registro de eventos
        </div>
    </div>
</div>