<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-20 09:05:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 53
ERROR - 2021-12-20 09:59:09 --> Severity: error --> Exception: Call to undefined method CI_Input::delete() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 233
ERROR - 2021-12-20 10:19:46 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:19:46 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:19:46 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:19:46 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:20:38 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:20:38 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:20:38 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:20:38 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:20:40 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:20:40 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:20:40 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:20:40 --> Severity: Warning --> Undefined property: stdClass::$typePro C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:21:42 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:21:42 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:21:42 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:21:42 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:21:44 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:21:44 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:21:44 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:21:44 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:24:46 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:24:46 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:24:46 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:24:46 --> Severity: Warning --> Undefined property: stdClass::$processDescription C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\processes\processeslisttable.php 35
ERROR - 2021-12-20 10:31:04 --> Severity: error --> Exception: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'ABONADO' for key 'name' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:33:53 --> Severity: error --> Exception: Unclosed '[' on line 92 does not match ')' C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Processes.php 93
ERROR - 2021-12-20 10:33:55 --> Severity: error --> Exception: Unclosed '[' on line 92 does not match ')' C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Processes.php 93
ERROR - 2021-12-20 10:35:21 --> Severity: error --> Exception: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'ABONADO' for key 'name' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:35:26 --> Severity: error --> Exception: SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry 'ABONADO' for key 'name' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:41:29 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:42:01 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:42:17 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:42:19 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:42:23 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:46:55 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:50:35 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:50:36 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:53:16 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 10:53:19 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'transactions.checkField' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 12:10:20 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 401
ERROR - 2021-12-20 12:10:59 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 401
ERROR - 2021-12-20 12:13:40 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 401
ERROR - 2021-12-20 12:13:41 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 401
ERROR - 2021-12-20 12:14:10 --> Severity: Warning --> Undefined variable $orderBy C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 399
ERROR - 2021-12-20 12:14:10 --> Severity: Warning --> Undefined variable $orderFormat C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 399
ERROR - 2021-12-20 12:14:10 --> Severity: Warning --> Undefined variable $allItems C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\items\itemsReport.php 49
ERROR - 2021-12-20 12:16:58 --> Severity: Warning --> Undefined variable $from_date C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 457
ERROR - 2021-12-20 12:16:58 --> Severity: Warning --> Undefined variable $to_date C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 458
ERROR - 2021-12-20 12:16:58 --> Severity: Warning --> Undefined variable $from_date C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 460
ERROR - 2021-12-20 12:16:58 --> Severity: Warning --> Undefined variable $to_date C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 460
ERROR - 2021-12-20 12:16:58 --> Severity: error --> Exception: SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND DATE(transactions.transDate) < `IS` `NULL`
GROUP BY `ref`
ORDER BY...' at line 4 C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 12:17:05 --> Severity: Warning --> Undefined variable $from_date C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 457
ERROR - 2021-12-20 12:17:05 --> Severity: Warning --> Undefined variable $to_date C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 458
ERROR - 2021-12-20 12:17:05 --> Severity: Warning --> Undefined variable $from_date C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 460
ERROR - 2021-12-20 12:17:05 --> Severity: Warning --> Undefined variable $to_date C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 460
ERROR - 2021-12-20 12:17:05 --> Severity: error --> Exception: SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '`NULL`
AND DATE(transactions.transDate) < `IS` `NULL`
GROUP BY `ref`
ORDER BY...' at line 4 C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 12:17:49 --> Severity: Warning --> Undefined variable $orderBy C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 399
ERROR - 2021-12-20 12:17:49 --> Severity: Warning --> Undefined variable $orderFormat C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 399
ERROR - 2021-12-20 12:17:49 --> Severity: Warning --> Undefined variable $allItems C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\items\itemsReport.php 49
ERROR - 2021-12-20 12:23:26 --> Severity: Warning --> Undefined variable $orderFormat C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 399
ERROR - 2021-12-20 12:23:26 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'name-ASC' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 12:23:27 --> Severity: Warning --> Undefined variable $orderFormat C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 399
ERROR - 2021-12-20 12:23:27 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'name-ASC' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 12:23:28 --> Severity: Warning --> Undefined variable $orderFormat C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 399
ERROR - 2021-12-20 12:23:28 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'name-ASC' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 12:24:58 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'name-ASC' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-20 12:26:02 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 401
ERROR - 2021-12-20 12:27:14 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 401
ERROR - 2021-12-20 12:27:18 --> Severity: error --> Exception: syntax error, unexpected variable "$this" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 401
ERROR - 2021-12-20 12:38:49 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-20 12:43:03 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-20 12:43:29 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-20 13:40:58 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 38
ERROR - 2021-12-20 13:40:58 --> Severity: Warning --> Undefined property: stdClass::$deleted C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 13:40:58 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 38
ERROR - 2021-12-20 13:40:58 --> Severity: Warning --> Undefined property: stdClass::$deleted C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 13:42:08 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 38
ERROR - 2021-12-20 13:42:08 --> Severity: Warning --> Undefined property: stdClass::$deleted C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 13:42:08 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 38
ERROR - 2021-12-20 13:42:08 --> Severity: Warning --> Undefined property: stdClass::$deleted C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 13:42:45 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 38
ERROR - 2021-12-20 13:42:45 --> Severity: Warning --> Undefined property: stdClass::$deleted C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 13:42:45 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 38
ERROR - 2021-12-20 13:42:45 --> Severity: Warning --> Undefined property: stdClass::$deleted C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 13:43:50 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 38
ERROR - 2021-12-20 13:43:50 --> Severity: Warning --> Undefined property: stdClass::$cancelled C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 13:43:50 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 38
ERROR - 2021-12-20 13:43:50 --> Severity: Warning --> Undefined property: stdClass::$cancelled C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 13:46:08 --> Severity: Warning --> Undefined property: stdClass::$cancelled C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 27
ERROR - 2021-12-20 13:46:08 --> Severity: Warning --> Undefined property: stdClass::$cancelled C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 27
ERROR - 2021-12-20 13:46:11 --> Severity: Warning --> Undefined property: stdClass::$cancelled C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 27
ERROR - 2021-12-20 13:46:11 --> Severity: Warning --> Undefined property: stdClass::$cancelled C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 27
ERROR - 2021-12-20 15:10:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:10:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:10:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:10:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:10:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:10:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:10:48 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:12:28 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:12:28 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:12:28 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:12:28 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:12:28 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:12:28 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:12:28 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-20 15:36:27 --> Severity: Warning --> Undefined property: stdClass::$resType C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 27
ERROR - 2021-12-20 15:36:27 --> Severity: Warning --> Undefined property: stdClass::$resType C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 27
ERROR - 2021-12-20 15:48:25 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 15:48:25 --> Severity: error --> Exception: Attempt to assign property "quantity" on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 44
ERROR - 2021-12-20 15:48:43 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 15:48:43 --> Severity: error --> Exception: Attempt to assign property "quantity" on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 44
ERROR - 2021-12-20 15:49:19 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 15:49:19 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 15:49:42 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 15:49:42 --> Severity: Warning --> Undefined property: stdClass::$id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\reservations\restable.php 39
ERROR - 2021-12-20 15:58:06 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'restId' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
