<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-07 00:10:33 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 00:10:33 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
ERROR - 2021-12-07 00:36:03 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 00:36:03 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
ERROR - 2021-12-07 00:36:06 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 00:36:06 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
ERROR - 2021-12-07 00:36:10 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 00:36:12 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 00:36:19 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 00:36:19 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 00:36:20 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 00:36:20 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
ERROR - 2021-12-07 00:46:24 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 00:46:25 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 00:46:25 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
ERROR - 2021-12-07 00:46:28 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 00:46:28 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
ERROR - 2021-12-07 01:09:37 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:09:37 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:14:02 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:14:02 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:14:07 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:14:07 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:14:09 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 01:15:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:15:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:15:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:15:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:15:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:15:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:15:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:27:34 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:27:34 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:27:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:27:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:27:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:27:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:27:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:27:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:27:34 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:55 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:28:55 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:28:56 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:56 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:58 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:28:58 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:28:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:58 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:28:58 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:28:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:28:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:35 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:29:35 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:29:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:29:35 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:34:30 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:34:30 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:34:30 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:34:30 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:34:30 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:34:30 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:34:30 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:34:30 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:34:30 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:28 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:36:28 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:36:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:36:29 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:51:09 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:51:09 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:51:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:51:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:51:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:51:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:51:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:51:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:51:09 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-07 01:51:13 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:51:13 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:51:15 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:51:15 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:51:16 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:51:16 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:53:39 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 01:53:39 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:05:02 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:05:02 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:42:32 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:42:32 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:44:37 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:44:37 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:50:21 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:50:21 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:55:07 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:55:07 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:55:07 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:55:07 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:58:19 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:58:19 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:58:45 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 02:58:45 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:11:08 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:11:08 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:17:18 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:17:18 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:17:26 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:17:26 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:20:10 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:20:10 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:32:30 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:32:30 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:34:02 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:34:02 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:34:37 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:34:37 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:36:03 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:36:03 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:45:28 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:45:28 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:46:09 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:46:09 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:46:21 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 03:46:21 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-07 04:29:16 --> 404 Page Not Found: Clients/lacl_
ERROR - 2021-12-07 04:29:18 --> 404 Page Not Found: Clients/lacl_
ERROR - 2021-12-07 04:29:19 --> 404 Page Not Found: Clients/lacl_
ERROR - 2021-12-07 04:29:22 --> 404 Page Not Found: Clients/lacl_
ERROR - 2021-12-07 05:11:23 --> 404 Page Not Found: Suppliers/lacl_
ERROR - 2021-12-07 05:12:01 --> 404 Page Not Found: Suppliers/lacl_
ERROR - 2021-12-07 05:13:41 --> 404 Page Not Found: Suppliers/lacl_
ERROR - 2021-12-07 05:13:42 --> 404 Page Not Found: Suppliers/lacl_
ERROR - 2021-12-07 05:13:43 --> 404 Page Not Found: Suppliers/lacl_
ERROR - 2021-12-07 05:13:44 --> 404 Page Not Found: Suppliers/lacl_
ERROR - 2021-12-07 05:13:45 --> 404 Page Not Found: Suppliers/lacl_
ERROR - 2021-12-07 05:47:04 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:49:22 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:49:40 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:50:53 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:51:34 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:51:36 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:51:39 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:54:48 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:54:52 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:55:01 --> 404 Page Not Found: Public/js
ERROR - 2021-12-07 05:55:20 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:58:43 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 05:58:43 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:58:45 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 05:58:46 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:58:48 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:59:34 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 05:59:35 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 05:59:37 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 05:59:39 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 55
ERROR - 2021-12-07 06:00:31 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 06:00:32 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 06:00:34 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 55
ERROR - 2021-12-07 06:00:36 --> Severity: error --> Exception: Class Processes already exists and doesn't extend CI_Model C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\core\Loader.php 349
ERROR - 2021-12-07 06:01:24 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 55
ERROR - 2021-12-07 06:01:41 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:01:56 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:01:59 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:02:01 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:02:36 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.process' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:02:38 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.process' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:02:39 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.process' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:02:58 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:03:41 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:05:13 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:05:15 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:05:16 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:05:19 --> 404 Page Not Found: Process/index
ERROR - 2021-12-07 06:05:24 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 06:06:06 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 55
ERROR - 2021-12-07 06:06:09 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 55
ERROR - 2021-12-07 06:10:45 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 55
ERROR - 2021-12-07 10:09:36 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 10:30:40 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:30:42 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 10:30:43 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:32:25 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:32:27 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 10:32:28 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:32:30 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:32:31 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:32:32 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:32:36 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:38:31 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:38:32 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:38:33 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:42:44 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:42:45 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:42:47 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:56:50 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:56:52 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:56:53 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 10:56:55 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:56:56 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 10:56:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 10:56:59 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:02:06 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:02:07 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:04:53 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:04:54 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:05:01 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:05:03 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:05:22 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:06:23 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:07:39 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 11:07:41 --> 404 Page Not Found: Processes/lapr
ERROR - 2021-12-07 11:10:27 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 11:10:28 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 11:59:37 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-07 11:59:39 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 55
ERROR - 2021-12-07 11:59:47 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:03:07 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2021-12-07 13:04:07 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:04:10 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:04:19 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:04:28 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:06:14 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:07:12 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:07:22 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:07:37 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:08:40 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2021-12-07 13:09:22 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:10:16 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:10:29 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:10:38 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:11:47 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:12:21 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:12:27 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:13:51 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:13:52 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:13:58 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:14:28 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:15:13 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:15:24 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:15:32 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2021-12-07 13:16:31 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:17:40 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:25:15 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:25:17 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:30:27 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'resId' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:30:29 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'resId' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:30:30 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'resId' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:30:32 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'resId' in 'order clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:33:27 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2021-12-07 13:34:03 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:35:08 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2021-12-07 13:35:49 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:38:07 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2021-12-07 13:39:36 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:39:43 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:39:48 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'reservations.resDate' in 'field list' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:40:48 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:48:03 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:48:14 --> Severity: error --> Exception: Call to undefined method CI_DB_pdo_mysql_driver::res_start() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Reservations.php 259
ERROR - 2021-12-07 13:50:33 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:51:04 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2021-12-07 13:53:00 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:53:01 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:53:16 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 13:53:21 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2021-12-07 14:38:02 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 14:38:03 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2021-12-07 14:38:04 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2021-12-07 14:38:05 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2021-12-07 14:39:09 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 14:39:16 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 15:14:06 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 15:18:27 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 15:18:30 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 20:02:52 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-07 20:03:25 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'processCode' in 'where clause' C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
