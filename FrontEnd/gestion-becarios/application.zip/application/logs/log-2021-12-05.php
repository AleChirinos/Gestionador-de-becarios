<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-05 23:42:40 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-05 23:44:28 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-05 23:44:29 --> 404 Page Not Found: Public/bootstrap
