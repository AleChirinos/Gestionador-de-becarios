<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-14 00:58:37 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2022-01-14 00:58:48 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2022-01-14 00:59:23 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2022-01-14 01:36:17 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-14 01:38:33 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
