<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-06 00:09:12 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 00:10:03 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 00:31:10 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 00:32:27 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:03:22 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:03:43 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:04:04 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:21:50 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:24:09 --> 404 Page Not Found: Public/js
ERROR - 2021-12-06 02:24:38 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:24:43 --> 404 Page Not Found: Public/js
ERROR - 2021-12-06 02:27:47 --> 404 Page Not Found: Public/js
ERROR - 2021-12-06 02:31:05 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:32:05 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:33:11 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:41:01 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:42:18 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:43:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:43:14 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:43:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:43:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:43:17 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:43:18 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:43:19 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:08 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:10 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:12 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:13 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:13 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:13 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:13 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:13 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:13 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:13 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:14 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:14 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:14 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:14 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:14 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:14 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:14 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:15 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:44:59 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:45:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:45:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:45:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:45:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:45:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:45:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:45:00 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:45:14 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:46:22 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:47:36 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:37 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:37 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:37 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:37 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:37 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:37 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:46 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:49 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:49 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:49 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:49 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:49 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:49 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:47:49 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:48:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:48:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:48:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:48:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:48:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:48:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:48:21 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:48:28 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:48:31 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:49:01 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:49:23 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:49:26 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:49:29 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:50:09 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:50:12 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:50:38 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:50:58 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:50:59 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:51:19 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:51:54 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:52:46 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:54:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:54:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:54:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:54:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:54:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:54:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:54:11 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:52 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:52 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:52 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:52 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:52 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:52 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:52 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:53 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:53 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:53 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:53 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:53 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:53 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:53 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:56:54 --> 404 Page Not Found: Public/bootstrap
ERROR - 2021-12-06 02:59:27 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:59:49 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 02:59:59 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 03:00:01 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 03:00:09 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 03:00:10 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 03:00:12 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 03:00:22 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 03:00:28 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 03:01:22 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 03:01:23 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 04:18:47 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 04:21:59 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 12:39:20 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:01:37 --> 404 Page Not Found: Supliers/index
ERROR - 2021-12-06 13:01:41 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:01:42 --> 404 Page Not Found: Supliers/index
ERROR - 2021-12-06 13:01:45 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:08:39 --> 404 Page Not Found: Supliers/index
ERROR - 2021-12-06 13:08:42 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:09:11 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:09:18 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:10:36 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:10:37 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:10:41 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:14:36 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:14:37 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:16:40 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:19:40 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 55
ERROR - 2021-12-06 13:34:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Reservation C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\core\Loader.php 344
ERROR - 2021-12-06 15:50:50 --> Severity: error --> Exception: C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models/Client.php exists, but doesn't declare class Client C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\core\Loader.php 336
ERROR - 2021-12-06 16:03:11 --> Severity: error --> Exception: C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models/Client.php exists, but doesn't declare class Client C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\core\Loader.php 336
ERROR - 2021-12-06 16:07:33 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 16:07:34 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.client' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-06 16:14:48 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 16:14:48 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.client' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-06 16:25:22 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 16:25:22 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.client' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-06 16:32:31 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 16:32:31 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.client' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-06 16:32:45 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 16:32:45 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.client' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-06 16:35:08 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 16:35:08 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.client' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-06 23:34:08 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 23:34:08 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.client' doesn't exist C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2021-12-06 23:54:26 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 23:54:26 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
ERROR - 2021-12-06 23:54:29 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 23:54:29 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
ERROR - 2021-12-06 23:54:31 --> Severity: Warning --> Undefined array key "client_id" C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\models\Client.php 140
ERROR - 2021-12-06 23:54:31 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Clients.php 55
