<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-22 15:05:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:06:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:07:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:08:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:13:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:18:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:19:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:19:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:25:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 15:25:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 23:23:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 23:23:14 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-22 23:23:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 23:23:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 23:23:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 23:23:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 23:23:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-22 23:23:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
