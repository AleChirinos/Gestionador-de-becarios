<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-20 01:33:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:33:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:33:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:33:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:33:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:33:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:33:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:38:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:38:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:38:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:38:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:38:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:38:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:38:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:39:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:39:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:39:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:39:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:39:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 01:39:30 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 09:46:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 09:51:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 09:57:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 10:11:53 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 10:11:53 --> Severity: Warning --> Undefined variable $login_url C:\xampp\htdocs\gestion-becarios\application\views\home.php 105
ERROR - 2022-01-20 10:11:54 --> Severity: Warning --> Undefined variable $login_url C:\xampp\htdocs\gestion-becarios\application\views\home.php 105
ERROR - 2022-01-20 11:02:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:02:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:12:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:12:29 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 11:13:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:13:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:13:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:13:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:25:01 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 11:25:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:25:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:25:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:25:56 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 11:26:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:26:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:27:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:28:46 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 11:28:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:28:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:32:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:32:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:35:19 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 11:36:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:36:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:36:53 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 11:58:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 11:58:03 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 12:12:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 12:13:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 12:13:21 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 12:15:13 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 12:19:53 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 50
ERROR - 2022-01-20 12:19:53 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 50
ERROR - 2022-01-20 12:39:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 12:39:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 12:40:19 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 12:40:25 --> Severity: error --> Exception: Call to undefined method Controller::checkUserExist() C:\xampp\htdocs\gestion-becarios\application\views\home.php 59
ERROR - 2022-01-20 12:40:58 --> Severity: error --> Exception: Call to undefined method Controller::checkUserExist() C:\xampp\htdocs\gestion-becarios\application\views\home.php 59
ERROR - 2022-01-20 12:41:02 --> Severity: error --> Exception: Call to undefined method Controller::checkUserExist() C:\xampp\htdocs\gestion-becarios\application\views\home.php 59
ERROR - 2022-01-20 12:41:11 --> Severity: error --> Exception: Call to undefined method Controller::checkUserExist() C:\xampp\htdocs\gestion-becarios\application\views\home.php 59
ERROR - 2022-01-20 12:41:12 --> Severity: error --> Exception: Call to undefined method Controller::checkUserExist() C:\xampp\htdocs\gestion-becarios\application\views\home.php 59
ERROR - 2022-01-20 12:42:03 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:42:21 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:44:58 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:47:10 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:48:15 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:48:23 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:50:15 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:50:50 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:50:51 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:50:52 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:50:52 --> Severity: error --> Exception: Cannot use object of type PDOStatement as array C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 65
ERROR - 2022-01-20 12:52:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 12:52:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 12:52:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 12:52:35 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 12:52:43 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 12:52:43 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 12:52:43 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 12:52:43 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:11:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:11:09 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:11:09 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:11:10 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:11:33 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:11:34 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:11:48 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:11:48 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:13:04 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:13:05 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:13:06 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:13:06 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:18:02 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:18:03 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:18:10 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:10 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:10 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:10 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:16 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:16 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:16 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:16 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:18 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:18 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:18 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:18 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:29 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:55 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:55 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:56 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:56 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:59 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:18:59 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:00 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:00 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:01 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:01 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:02 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:02 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:43 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:43 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:43 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:43 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:44 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:47 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:47 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:48 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:48 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:48 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:48 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:49 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:49 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:49 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:49 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:49 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:19:49 --> Severity: Warning --> Trying to access array offset on value of type bool C:\xampp\htdocs\gestion-becarios\core\controller.Class.php 73
ERROR - 2022-01-20 13:20:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:20:09 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:20:09 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:20:09 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:20:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:20:25 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:20:25 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:20:25 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 90
ERROR - 2022-01-20 13:20:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:21:35 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:21:35 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:21:35 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:22:03 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:22:04 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:22:05 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:22:05 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:24:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:24:36 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:24:36 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:24:36 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:25:10 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:25:10 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:25:21 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:25:22 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:28:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:28:38 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:28:38 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:28:39 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:29:03 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:29:03 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:29:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:30:00 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:30:00 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:30:00 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 91
ERROR - 2022-01-20 13:40:39 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 92
ERROR - 2022-01-20 13:40:39 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 92
ERROR - 2022-01-20 13:40:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:40:48 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:40:48 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 92
ERROR - 2022-01-20 13:40:48 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\gestion-becarios\application\views\home.php 92
ERROR - 2022-01-20 13:41:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:45:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:45:42 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 13:53:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:53:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:53:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 13:53:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:05:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:06:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:06:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:06:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:07:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:07:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:14:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:15:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:15:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:15:35 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:15:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:15:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:18:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:18:16 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:18:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:18:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:18:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:20:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:20:05 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:20:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:20:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:20:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:20:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:20:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:20:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:20:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:48 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:21:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:21:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:23:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:23:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:23:29 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:23:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:23:41 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:23:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:31:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:31:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:41:05 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:41:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:41:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:21 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:45:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:37 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 14:45:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:45:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:46:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:46:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:46:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:46:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 14:46:35 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 15:35:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:35:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:35:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:35:58 --> Severity: Warning --> foreach() argument must be of type array|object, bool given C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajos.php 243
ERROR - 2022-01-20 15:35:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:40:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:40:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:40:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:40:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:40:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:40:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:41:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:41:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:41:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:49:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:49:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:49:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:49:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:50:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:15 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 15:53:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:53:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:54:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:54:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:54:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:54:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:54:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:54:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:57:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:20 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 15:58:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:46 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 15:58:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 15:58:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:07 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 16:05:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:05:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:06:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:06:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:06:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:06:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:06:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:06:24 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 16:06:37 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 16:06:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:06:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:07:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:07:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:07:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:08:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:08:50 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 16:08:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:09:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:09:11 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 16:09:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:09:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:11:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:11:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:11:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:14:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:20:09 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-20 16:36:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:36:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:36:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:36:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:36:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:36:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:37:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:37:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:38:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:40:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:41:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:41:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:42:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 16:52:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 17:39:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-20 17:39:39 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
