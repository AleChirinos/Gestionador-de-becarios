<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-11 00:40:59 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 01:02:26 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\items\itemslisttable.php 49
ERROR - 2022-01-11 01:02:26 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\items\itemslisttable.php 49
ERROR - 2022-01-11 01:05:23 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\items\itemslisttable.php 49
ERROR - 2022-01-11 01:05:23 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\items\itemslisttable.php 49
ERROR - 2022-01-11 01:13:08 --> Severity: 8192 --> number_format(): Passing null to parameter #1 ($num) of type float is deprecated C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\views\items\itemslisttable.php 49
ERROR - 2022-01-11 01:14:08 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 01:55:54 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 01:55:54 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 01:56:22 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 01:56:22 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 01:56:25 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 01:56:25 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 01:56:28 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 01:56:28 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:01:04 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:01:04 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:01:23 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:01:23 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:07:17 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:07:17 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:10:12 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:10:12 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:10:14 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:10:14 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:13:15 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:13:15 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:15:41 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Dashboard.php 165
ERROR - 2022-01-11 02:15:43 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:15:43 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:17:06 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2022-01-11 02:17:07 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:17:07 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:17:07 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2022-01-11 02:17:08 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 02:17:11 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:17:11 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:18:06 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:18:06 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:18:11 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2022-01-11 02:18:12 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 02:18:14 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2022-01-11 02:18:15 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 02:18:16 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2022-01-11 02:18:16 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:18:16 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:33 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:33 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:36 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:36 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:46 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:46 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:49 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:49 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 02:31:53 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 02:31:53 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 02:31:53 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 15:44:53 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Dashboard.php 165
ERROR - 2022-01-11 15:44:56 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:44:56 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:45:33 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Dashboard.php 165
ERROR - 2022-01-11 15:45:34 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:45:34 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:45:41 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:45:41 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:47:47 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:47:47 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:47:58 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 82
ERROR - 2022-01-11 15:47:58 --> Severity: error --> Exception: Call to a member function add() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 82
ERROR - 2022-01-11 15:48:03 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 82
ERROR - 2022-01-11 15:48:03 --> Severity: error --> Exception: Call to a member function add() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 82
ERROR - 2022-01-11 15:48:41 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:48:41 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 15:48:52 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 82
ERROR - 2022-01-11 15:48:52 --> Severity: error --> Exception: Call to a member function add() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 82
ERROR - 2022-01-11 15:50:10 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 82
ERROR - 2022-01-11 15:50:10 --> Severity: error --> Exception: Call to a member function add() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 82
ERROR - 2022-01-11 16:02:16 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:02:16 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:02:27 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:02:27 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:02:31 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:02:31 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:02:33 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:02:33 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:03:48 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:03:48 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:04:20 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:04:20 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:06:29 --> Severity: Warning --> Undefined property: Becarios::$item C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:06:29 --> Severity: error --> Exception: Call to a member function getAll() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 52
ERROR - 2022-01-11 16:26:19 --> Severity: Warning --> Undefined variable $item_id C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Becarios.php 344
ERROR - 2022-01-11 16:30:00 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 20:22:53 --> Severity: error --> Exception: Division by zero C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Dashboard.php 165
ERROR - 2022-01-11 20:22:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 20:22:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2022-01-11 21:03:50 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:50 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:50 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:51 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:52 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:54 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:54 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:55 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:55 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:56 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:57 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:57 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:57 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:58 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:58 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:59 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:03:59 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:04:01 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:04:01 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:04:02 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:04:07 --> Severity: 8192 --> ctype_digit(): Argument of type null will be interpreted as string in the future C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\libraries\Pagination.php 522
ERROR - 2022-01-11 21:04:29 --> Severity: 8192 --> ctype_digit(): Argument of type null will be interpreted as string in the future C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\libraries\Pagination.php 522
ERROR - 2022-01-11 21:04:41 --> Severity: 8192 --> ctype_digit(): Argument of type null will be interpreted as string in the future C:\xampp\htdocs\mini-inventory-and-sales-management-system\system\libraries\Pagination.php 522
ERROR - 2022-01-11 21:13:16 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:16 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:16 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:16 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:17 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:17 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:17 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:18 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:18 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:18 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:19 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:19 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:13:19 --> Severity: error --> Exception: Call to undefined method Item::becariosearch() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:28 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:28 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:28 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:28 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:28 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:28 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:29 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:29 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:29 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:29 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:30 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:30 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:30 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:30 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:30 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:30 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:30 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:30 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:31 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:31 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:36 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:36 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:38 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:38 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:38 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:38 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:40 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:18:40 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:50 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:50 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:50 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:50 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:50 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:50 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:51 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:51 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:52 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:19:52 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:21:25 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 21:21:26 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 21:21:33 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 21:21:34 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Administrators.php 53
ERROR - 2022-01-11 21:21:35 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 21:21:35 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Suppliers.php 52
ERROR - 2022-01-11 21:22:20 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:21 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:22 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:22 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:22 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:23 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:23 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:23 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:23 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:25 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:25 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:25 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:26 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:22:26 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:23:23 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:23:24 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:23:24 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:23:24 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:23:24 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:23:24 --> 404 Page Not Found: Search/clientsearch
ERROR - 2022-01-11 21:23:29 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:23:29 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:23:31 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:23:31 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:28:43 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:28:43 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:28:47 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:28:47 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:28:47 --> Severity: Warning --> Undefined property: Search::$becario C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
ERROR - 2022-01-11 21:28:47 --> Severity: error --> Exception: Call to a member function becariosearch() on null C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Search.php 87
