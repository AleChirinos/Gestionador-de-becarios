<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-24 14:04:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:04:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:04:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:05:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:05:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:05:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:05:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:09:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:40 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:10:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:11:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:15:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 50
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 51
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 51
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 50
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 51
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 51
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 50
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 51
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 51
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 50
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 51
ERROR - 2022-01-24 14:15:56 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\gestion-becarios\application\views\becarios\becarioslisttable.php 51
ERROR - 2022-01-24 14:16:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 43
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 44
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 44
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 43
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 44
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 44
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 43
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 44
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 44
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 43
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> Undefined variable $allAsignaciones C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 44
ERROR - 2022-01-24 14:16:05 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\gestion-becarios\application\views\trabajos\trabajoslisttable.php 44
ERROR - 2022-01-24 14:16:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 14:16:17 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:17 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:18 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:19 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:19 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:19 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:19 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:19 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:20 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:20 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:20 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:20 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:20 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:21 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:21 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:21 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 14:16:21 --> 404 Page Not Found: Search/adminsearch
ERROR - 2022-01-24 15:43:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 15:44:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 15:44:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 15:44:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 15:45:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 16:53:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:00:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:17:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:32:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:32:26 --> 404 Page Not Found: Administrators/addManagement
ERROR - 2022-01-24 17:32:27 --> 404 Page Not Found: Administrators/addManagement
ERROR - 2022-01-24 17:32:43 --> 404 Page Not Found: Administrators/addManagement
ERROR - 2022-01-24 17:37:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:38:06 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:38:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:38:08 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:38:08 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:44:31 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:44:31 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:44:31 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:47:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:47:15 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:47:16 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:47:16 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:47:17 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:47:17 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:47:17 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:49:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:49:06 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:49:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:49:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:49:27 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:50:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:50:24 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:50:24 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:50:25 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:50:25 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:50:25 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:50:26 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:50:26 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:51:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:51:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:51:08 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:51:08 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:51:08 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:53:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 17:54:49 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:54:50 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:54:50 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:54:50 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:54:50 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:58:06 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:58:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:58:07 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:59:41 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:59:41 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:59:42 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:59:42 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:59:42 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:59:42 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 17:59:42 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:17 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:19 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:27 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:28 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:28 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:28 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:28 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:29 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:29 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:29 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:29 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:29 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:30 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:30 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:33 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:33 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:36 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:36 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:37 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:37 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:37 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:39 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:39 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:06:40 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:13:44 --> Severity: 8192 --> trim(): Passing null to parameter #1 ($string) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Form_validation.php 1059
ERROR - 2022-01-24 18:22:02 --> Severity: Warning --> Undefined property: Administrators::$management C:\xampp\htdocs\gestion-becarios\application\controllers\Administrators.php 159
ERROR - 2022-01-24 18:22:02 --> Severity: error --> Exception: Call to a member function add() on null C:\xampp\htdocs\gestion-becarios\application\controllers\Administrators.php 159
ERROR - 2022-01-24 19:21:36 --> Severity: Warning --> Undefined property: Administrators::$management C:\xampp\htdocs\gestion-becarios\application\controllers\Administrators.php 159
ERROR - 2022-01-24 19:21:36 --> Severity: error --> Exception: Call to a member function add() on null C:\xampp\htdocs\gestion-becarios\application\controllers\Administrators.php 159
ERROR - 2022-01-24 19:27:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Management C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-24 19:28:48 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 19:29:05 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 19:36:29 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 19:37:18 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:43 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:44 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:45 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:45 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:45 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:45 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:45 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:46 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:46 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:46 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:46 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:46 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:49 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:49 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:34:59 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:43:35 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:43:35 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:46:11 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-24 22:48:09 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
