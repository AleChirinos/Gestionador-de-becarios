<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-25 19:48:16 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 19:48:28 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 19:54:45 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-25 20:27:22 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-25 20:32:30 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:39:39 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:40:12 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:40:27 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:44:13 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:48:04 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:48:07 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:48:07 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:48:08 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:48:09 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:48:09 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:48:10 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 20:54:42 --> 404 Page Not Found: Administrators/addM
ERROR - 2022-01-25 20:58:24 --> 404 Page Not Found: Administrators/addM
ERROR - 2022-01-25 20:59:21 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 21:29:13 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'first_name' in 'order clause' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 21:29:37 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 21:29:49 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 21:36:50 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'first_name' in 'order clause' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 21:37:04 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'first_name' in 'order clause' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-25 22:31:39 --> 404 Page Not Found: Managements/index
