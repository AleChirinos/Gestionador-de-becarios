<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-26 00:41:58 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 00:43:41 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'created_on' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 00:48:03 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-26 01:18:53 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-26 01:30:16 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-26 01:37:24 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-26 02:04:13 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-26 02:18:45 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'hours' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 02:23:50 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\gestion-becarios\system\core\Output.php 457
ERROR - 2022-01-26 02:25:21 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-26 15:25:07 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-26 16:41:25 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 16:42:00 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:42:08 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:42:11 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:43:16 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:43:20 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:43:25 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-26 16:43:33 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:44:44 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:47:59 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:48:00 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:48:04 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:52:06 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:52:08 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:54:00 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:54:52 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:55:21 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 16:56:10 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:00:06 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:01:04 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:01:06 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:01:29 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:02:39 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:04:41 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:04:43 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:04:45 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:07:35 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:07:36 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:07:37 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:07:38 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:07:39 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:08:46 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:10:00 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:10:37 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:11:26 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:12:08 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:15:07 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:17:23 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:18:13 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:20:11 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:22:05 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:27:13 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:27:14 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:27:16 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 17:27:17 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.transactions' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 18:05:41 --> 404 Page Not Found: Semesters/lilt
ERROR - 2022-01-26 18:07:12 --> 404 Page Not Found: Semesters/lilt
ERROR - 2022-01-26 18:10:20 --> 404 Page Not Found: Semesters/lilt
ERROR - 2022-01-26 18:14:17 --> 404 Page Not Found: Items/index
ERROR - 2022-01-26 18:22:47 --> Severity: error --> Exception: SQLSTATE[42S22]: Column not found: 1054 Unknown column 'unitPrice' in 'field list' C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-26 18:29:20 --> Severity: error --> Exception: Call to undefined method Item::getItemsCumTotal() C:\xampp\htdocs\gestion-becarios\application\controllers\Semesters.php 72
ERROR - 2022-01-26 18:29:23 --> Severity: error --> Exception: Call to undefined method Item::getItemsCumTotal() C:\xampp\htdocs\gestion-becarios\application\controllers\Semesters.php 72
ERROR - 2022-01-26 18:32:23 --> Severity: error --> Exception: Call to undefined method Item::getItemsCumTotal() C:\xampp\htdocs\gestion-becarios\application\controllers\Semesters.php 72
ERROR - 2022-01-26 18:32:25 --> Severity: error --> Exception: Call to undefined method Item::getItemsCumTotal() C:\xampp\htdocs\gestion-becarios\application\controllers\Semesters.php 72
ERROR - 2022-01-26 18:32:26 --> Severity: error --> Exception: Call to undefined method Item::getItemsCumTotal() C:\xampp\htdocs\gestion-becarios\application\controllers\Semesters.php 72
ERROR - 2022-01-26 18:35:07 --> Severity: error --> Exception: Call to undefined method Item::getItemsCumTotal() C:\xampp\htdocs\gestion-becarios\application\controllers\Semesters.php 72
ERROR - 2022-01-26 18:36:09 --> Severity: error --> Exception: Call to undefined method Item::getItemsCumTotal() C:\xampp\htdocs\gestion-becarios\application\controllers\Semesters.php 72
ERROR - 2022-01-26 18:36:10 --> Severity: error --> Exception: Call to undefined method Item::getItemsCumTotal() C:\xampp\htdocs\gestion-becarios\application\controllers\Semesters.php 72
ERROR - 2022-01-26 18:40:50 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:40:53 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:41:09 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:46:03 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:46:33 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:46:41 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:46:44 --> 404 Page Not Found: Semester/index
ERROR - 2022-01-26 18:46:51 --> 404 Page Not Found: Items/index
ERROR - 2022-01-26 18:46:58 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:47:54 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:47:56 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:47:57 --> 404 Page Not Found: Semesters/index
ERROR - 2022-01-26 18:48:02 --> 404 Page Not Found: Semesters/index
