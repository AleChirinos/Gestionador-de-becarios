<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-21 03:10:49 --> Severity: error --> Exception: Class "Transactions\CI_Controller" not found C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 13
ERROR - 2021-12-21 03:12:26 --> Severity: Compile Error --> Namespace declaration statement has to be the very first statement or after any declare call in the script C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Items.php 9
ERROR - 2021-12-21 03:13:32 --> Severity: error --> Exception: Call to undefined function generateRandomCode() C:\xampp\htdocs\mini-inventory-and-sales-management-system\application\controllers\Transactions.php 257
