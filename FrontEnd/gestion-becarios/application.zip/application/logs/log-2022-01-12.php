<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-12 14:37:14 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.becarios' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-12 14:37:15 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Administrators.php 53
ERROR - 2022-01-12 14:37:25 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Administrators.php 53
ERROR - 2022-01-12 16:55:33 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-12 16:55:39 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Administrators.php 53
ERROR - 2022-01-12 18:06:59 --> 404 Page Not Found: Login/index
ERROR - 2022-01-12 18:43:29 --> 404 Page Not Found: Gloginphp/index
ERROR - 2022-01-12 18:44:22 --> 404 Page Not Found: Applications/index
ERROR - 2022-01-12 22:05:51 --> 404 Page Not Found: Controllersphp/index
