<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-17 17:25:22 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 17:30:04 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 17:30:06 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-17 17:30:11 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 17:30:13 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Suppliers.php 52
ERROR - 2022-01-17 17:30:15 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 17:30:26 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Suppliers.php 52
ERROR - 2022-01-17 17:33:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:33:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:33:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:33:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:33:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:45 --> Severity: Warning --> Undefined variable $totalTransactions C:\xampp\htdocs\gestion-becarios\application\views\dashboard.php 23
ERROR - 2022-01-17 17:34:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:54 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 17:34:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Suppliers.php 52
ERROR - 2022-01-17 17:34:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:34:59 --> Severity: Warning --> Undefined variable $totalTransactions C:\xampp\htdocs\gestion-becarios\application\views\dashboard.php 23
ERROR - 2022-01-17 17:34:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:42 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 17:35:42 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:44 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Suppliers.php 52
ERROR - 2022-01-17 17:35:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:51 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 17:35:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:54 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Suppliers.php 52
ERROR - 2022-01-17 17:35:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:54 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Suppliers.php 52
ERROR - 2022-01-17 17:35:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:35:56 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, bool given C:\xampp\htdocs\gestion-becarios\application\controllers\Suppliers.php 52
ERROR - 2022-01-17 17:37:12 --> 404 Page Not Found: Suppliers/index
ERROR - 2022-01-17 17:37:14 --> 404 Page Not Found: Suppliers/index
ERROR - 2022-01-17 17:37:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:23 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 17:37:31 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 17:37:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:33:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:33:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:33:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:33:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:35:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:35:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:35:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:35:35 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 18:35:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:35:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:35:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:36:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:36:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:37:51 --> Severity: error --> Exception: Unable to locate the model you have specified: Item C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:39:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Item C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:40:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:40:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:40:31 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 18:40:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:40:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:40:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:42:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:42:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:42:38 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:42:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:43:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:43:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:43:28 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 18:43:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:43:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:43:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:43:31 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.trabajos' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 18:43:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:43:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:45:33 --> Severity: error --> Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table '1410inventory.items' doesn't exist C:\xampp\htdocs\gestion-becarios\system\database\drivers\pdo\pdo_driver.php 184
ERROR - 2022-01-17 18:49:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:50:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:53:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:53:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:53:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:55:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:55:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:56:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:56:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:56:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:56:01 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:56:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:56:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:56:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:56:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:59:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:59:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:59:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:59:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:59:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:59:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:59:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 18:59:55 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-17 18:59:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:00:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:00:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:00:04 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:00:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:00:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:00:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:00:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:00:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:03:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:03:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:04:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:04:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:04:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:04:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:04:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:04:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:04:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:05:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:05:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:05:47 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-17 19:05:47 --> 404 Page Not Found: Public/images
ERROR - 2022-01-17 19:05:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:06:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:06:22 --> Severity: 8192 --> setcookie(): Passing null to parameter #2 ($value) of type string is deprecated C:\xampp\htdocs\gestion-becarios\system\libraries\Session\Session_driver.php 132
ERROR - 2022-01-17 19:08:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:09:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:09:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:10:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:11:05 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:15:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:15:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:15:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:15:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:15:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:15:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:15:08 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:15:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:50:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:50:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:50:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:50:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:50:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:50:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:06 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:14 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:16 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:52:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:56:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:57:58 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 19:58:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:07:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:07:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:08:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:08:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:09:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:13:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:13:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:14:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:14:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:14:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:56 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:40:57 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:41:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:41:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:41:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:41:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:41:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:41:21 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 20:52:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 21:03:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 21:03:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 21:03:46 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 21:03:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 21:03:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 21:03:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
ERROR - 2022-01-17 21:03:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Transaction C:\xampp\htdocs\gestion-becarios\system\core\Loader.php 344
